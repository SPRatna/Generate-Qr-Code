-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2021 at 01:24 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `mobile`, `username`, `password`, `cpassword`, `status`, `created at`) VALUES
(1, 'Suraj', '8789532436', 'admin', '$2y$10$1H.OFev2l1zdL9HBJ5JKMO/VQqDDFjbTLrQz/81vxumrHHVql1Cdu', '$2y$10$1H.OFev2l1zdL9HBJ5JKMO/VQqDDFjbTLrQz/81vxumrHHVql1Cdu', '1', '2021-07-27 13:05:37');

-- --------------------------------------------------------

--
-- Table structure for table `partner`
--

CREATE TABLE `partner` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partner`
--

INSERT INTO `partner` (`id`, `name`, `mobile`, `username`, `password`, `cpassword`, `status`, `created at`) VALUES
(1, 'Suraj', '8789532436', 'suraj@gmail.com', '$2y$10$NnARsXHxFIDEF7QznF1e2u5gnP7cgEZc/aFocV1b/C6DBNE9WOa32', '$2y$10$NnARsXHxFIDEF7QznF1e2u5gnP7cgEZc/aFocV1b/C6DBNE9WOa32', '1', '2021-07-27 12:39:38');

-- --------------------------------------------------------

--
-- Table structure for table `qr`
--

CREATE TABLE `qr` (
  `id` int(11) NOT NULL,
  `pmode` varchar(255) NOT NULL COMMENT 'Payment Mode',
  `bgc` varchar(255) NOT NULL COMMENT 'Background Color',
  `ftc` varchar(255) NOT NULL COMMENT 'Front Color',
  `payee` varchar(255) NOT NULL COMMENT 'Payee Name',
  `paddr` varchar(500) NOT NULL COMMENT 'Payee Address',
  `bank` varchar(255) NOT NULL COMMENT 'Bank Name',
  `ifsc` varchar(255) NOT NULL COMMENT 'IFSC',
  `mob` varchar(11) NOT NULL COMMENT 'Mobile No.',
  `email` varchar(255) NOT NULL COMMENT 'Email',
  `status` enum('0','1') NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `qr`
--

INSERT INTO `qr` (`id`, `pmode`, `bgc`, `ftc`, `payee`, `paddr`, `bank`, `ifsc`, `mob`, `email`, `status`, `created at`) VALUES
(1, 'ba', 'white', 'black', 'Suraj', 'Patna', 'Canara Bank', 'CNRB004958', '8798789798', 'suraj@gmail.com', '1', '2021-07-29 07:13:17'),
(2, 'vpa', 'weqe', 'qweqw', 'sadasd', 'saddadad', 'dasdada', 'adsdasda', '5665656565', 'sddsds@dsfsf.com', '1', '2021-07-29 07:29:24'),
(3, 'vpa', 'weqe', 'qweqw', 'sadasd', 'saddadad', 'dasdada', 'adsdasda', '5665656565', 'sddsds@dsfsf.com', '1', '2021-07-29 08:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `qrcode`
--

CREATE TABLE `qrcode` (
  `id` int(11) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `file` varchar(1000) NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mob` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `mob`, `username`, `password`, `cpassword`, `image`, `status`, `created at`) VALUES
(7, 'Suraj Prakash Ratna', '8789532436', 'suraj@gmail.com', '$2y$10$EkJAucFOk1R6mcXgNvvI.OsXw51SEhvg2DL1/uFQztPFLXu0CeDMW', '$2y$10$BJFU7eGND8UDVaY/VZg.vuzh3AwxWom6CrGDFtLLkq3OarUGNcdIu', '2af3eacca026f9481c0109fa479703f4.jpg', '1', '2021-07-28 17:07:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partner`
--
ALTER TABLE `partner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qr`
--
ALTER TABLE `qr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qrcode`
--
ALTER TABLE `qrcode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `partner`
--
ALTER TABLE `partner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qr`
--
ALTER TABLE `qr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `qrcode`
--
ALTER TABLE `qrcode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
