<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {

	
	public function index()
	{
		$this->load->view('signup');
	}

	function __construct()
    {
        parent::__construct();
        $this->load->model('usersignupModel');
    }

    public function register()
    {
        $config['upload_path']          = './public/uploads/';
        $config['allowed_types']        = 'jpg|png';
        $config['encrypt_name']        = true;

        $this->load->library('upload', $config);
        $this->load->helper('common_helper');

    	$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
    	$this->form_validation->set_rules('name', 'Full Name', 'trim|required');
    	$this->form_validation->set_rules('mob', 'Mobile No.', 'trim|required|min_length[10]|max_length[10]|numeric');
    	$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
    	$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[12]');
    	$this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|matches[password]|min_length[4]|max_length[12]');
    	if($this->form_validation->run() == TRUE )
    	{
    		//Save in db
            if(!empty ($_FILES['image']['name']))
            {
                //Insert data with image
                if($this->upload->do_upload('image'))
                {
                    

                    //File uploaded successfully
                    $data = $this->upload->data();
                    //Resize image
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb/'.$data['file_name'], 300, 270);
                    $pass = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
                    $cpass = password_hash($this->input->post('cpassword'), PASSWORD_DEFAULT);
                    $formArray['image'] = $data['file_name'];
                    $formArray['name'] = $this->input->post('name');
                    $formArray['mob'] = $this->input->post('mob');
                    $formArray['username'] = $this->input->post('email');
                    $formArray['password'] = $pass;
                    $formArray['cpassword'] = $cpass;
                    $this->usersignupModel->create($formArray);

                    $this->session->set_flashdata('success', 'You are successfully registered.');
                    redirect(base_url().'user/signup/index');
                }else{
                    //we got somr errors
                    $error = $this->upload->display_errors('<p class="text-danger">','</p>');
                    $data['errorImageUpload'] = $error;
                    $this->load->view('signup', $data);
                }

            }else{
            //Insert data without image
            //password_hash('Krishna9', PASSWORD_DEFAULT);
            $pass = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
            $cpass = password_hash($this->input->post('cpassword'), PASSWORD_DEFAULT);
            $formArray['name'] = $this->input->post('name');
            $formArray['mob'] = $this->input->post('mob');
            $formArray['username'] = $this->input->post('email');
            $formArray['password'] = $pass;
            $formArray['cpassword'] = $cpass;
            $this->usersignupModel->create($formArray);

            $this->session->set_flashdata('success', 'You are successfully registered.');
            redirect(base_url().'user/signup/index');
            }
    		
    	}else{
    		//show error
    		$this->load->view('signup');
    	}

    	

    }


}
