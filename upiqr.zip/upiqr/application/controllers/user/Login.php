<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		//echo password_hash('Krishna9', PASSWORD_DEFAULT);
		$this->load->view('login');
	}

	public function authenticate()
	{
		$this->load->model('userModel');

		$this->form_validation->set_rules('username', 'Username', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|max_length[12]|min_length[4]|alpha_numeric_spaces');

		if($this->form_validation->run()==true)
		{
     //Success
			$username = $this->input->post('username');
			$user = $this->userModel->getByUsername($username);
			if(!empty($user))
			{
        //True
        $password = $this->input->post('password');
        if(password_verify($password, $user['password']) == true)
        {
          $userArray['user_id'] = $user['id'];
          $userArray['username'] = $user['username'];
          $this->session->set_userdata('user', $userArray );
          redirect(base_url().'user/dashboard/index');
        }else{
        	//Error Msg
       $this->session->set_flashdata('msg', 'Either username or password is incorrect');
       redirect(base_url().'user/Login/index');
        }

			}else{
       //Error Msg
       $this->session->set_flashdata('msg', 'Either username or password is incorrect');
       redirect(base_url().'user/Login/index');
			}
		}else{
     //Failed
			$this->load->view('login');
		}
	}

	public function logout()
	{
   $this->session->unset_userdata('user');
   redirect(base_url().'user/login/index');
	}
}