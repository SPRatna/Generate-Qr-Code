<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//echo password_hash('Krishna9', PASSWORD_DEFAULT);
		$this->load->view('partners/login');
	}
	
	public function authenticate()
	{
		$this->load->model('partnerModel');

		$this->form_validation->set_rules('username', 'Username', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|max_length[12]|min_length[4]|alpha_numeric_spaces');

		if($this->form_validation->run()==true)
		{
     //Success
			$username = $this->input->post('username');
			$user = $this->partnerModel->getByUsername($username);
			if(!empty($user))
			{
        //True
        $password = $this->input->post('password');
        if(password_verify($password, $user['password']) == true)
        {
          $userArray['user_id'] = $user['id'];
          $userArray['username'] = $user['username'];
          $this->session->set_userdata('partner', $userArray );
          redirect(base_url().'partners/dashboard/index');
        }else{
        	//Error Msg
       $this->session->set_flashdata('msg', 'Either username or password is incorrect');
       redirect(base_url().'partners/Login/index');
        }

			}else{
       //Error Msg
       $this->session->set_flashdata('msg', 'Either username or password is incorrect');
       redirect(base_url().'partners/Login/index');
			}
		}else{
     //Failed
			$this->load->view('partners/login');
		}
	}

	public function logout()
	{
   $this->session->unset_userdata('partner');
   redirect(base_url().'partners/login/index');
	}
}
