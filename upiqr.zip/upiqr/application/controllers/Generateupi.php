<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Generateupi extends CI_Controller {

	
	public function index()
	{
		$this->load->view('upiqrcode_generator');
	}

	function __construct()
    {
        parent::__construct();
        $this->load->model('userModel');
        /* Load QR Code Library */
        $this->load->library('ciqrcode');
    }

	

        public function add_data()
	{
        
       /* Form Validation */
        $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
        $this->form_validation->set_rules('pmode', 'Payment Mode', 'trim|required');
        $this->form_validation->set_rules('bgc', 'Background Color', 'trim|required');
        $this->form_validation->set_rules('ftc', 'Front Color', 'trim|required');
        $this->form_validation->set_rules('payee', 'Payee Name', 'trim|required');
        $this->form_validation->set_rules('paddr', 'Payee Address', 'trim|required');
        $this->form_validation->set_rules('bank', 'Name of Bank', 'trim|required');
        $this->form_validation->set_rules('ifsc', 'IFSC Code', 'trim|required');
        $this->form_validation->set_rules('mob', 'Mobile No.', 'trim|required|min_length[10]|max_length[10]|numeric');
        $this->form_validation->set_rules('email', 'Email Id', 'trim|required|valid_email');
        if($this->form_validation->run() == TRUE )
        {
            //Success
            $dataArray['pmode'] = $this->input->post('pmode');
            $dataArray['bgc'] = $this->input->post('bgc');
            $dataArray['ftc'] = $this->input->post('ftc');
            $dataArray['payee'] = $this->input->post('payee');
            $dataArray['paddr'] = $this->input->post('paddr');
            $dataArray['bank'] = $this->input->post('bank');
            $dataArray['ifsc'] = $this->input->post('ifsc');
            $dataArray['mob'] = $this->input->post('mob');
            $dataArray['email'] = $this->input->post('email');
            $dataArray['status'] = '1';
            $this->userModel->create($dataArray);
            //$qr = $this->generateQrcode($dataArray);
            $path='public/qrcode/';
            $file = $path.$dataArray['mob'].'.png';
            Qrcode::png($total, $file);
            $this->session->set_flashdata('success', 'You are successfully created.');
            redirect(base_url().'Generateupi/index');
        }else{
            // Error
            $this->load->view('upiqrcode_generator');
        }
        
      

    }
    
    public  function generateQrcode($dataArray)
        {
            
            
            /* Data */
            $hex_data   = bin2hex($dataArray);
            $save_name  = $hex_data.'.png';

            /* QR Code File Directory Initialize */
            $dir = 'public/qrcode/';
            if (!file_exists($dir)) {
                mkdir($dir, 0775, true);
            }

            /* QR Configuration  */
            $config['cacheable']    = true;
            $config['imagedir']     = $dir;
            $config['quality']      = true;
            $config['size']         = '1024';
            $config['black']        = array(255,255,255);
            $config['white']        = array(255,255,255);
            $this->ciqrcode->initialize($config);
      
            /* QR Data  */
            $params['data']     = $dataArray;
            $params['level']    = 'L';
            $params['size']     = 10;
            $params['savename'] = FCPATH.$config['imagedir']. $save_name;
            
            $this->ciqrcode->generate($params);

            /* Return Data */
            $return = array(
                'content' => $dataArray,
                'file'    => $dir. $save_name
            );
            return $return;
        }

	


}
