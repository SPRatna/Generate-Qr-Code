<section id="footer" class="mt-5">
  <div class="container-fluid bg-qr">
    <div class="row justify-content-center">
      <div class="col-lg-3 col-md-3 col-12 mt-5">
        <a href="" class="text-decoration-none"><strong>About</strong></a><br>
        <a href="<?php echo base_url();?>upi" class="text-decoration-none p1">Home</a><br>
        <a href="" class="text-decoration-none p1">About Us</a><br>
        <a href="<?php echo base_url();?>privacy_policy" class="text-decoration-none p1">Privacy Policy</a><br>
        <a href="<?php echo base_url();?>termsndconditions" class="text-decoration-none p1">Terms & Conditions</a><br>
        <a href="<?php echo base_url();?>contact" class="text-decoration-none p1">Contact Us</a><br>
      </div>
      <div class="col-lg-3 col-md-3 col-12 mt-5">
        <a href="" class="text-decoration-none"><strong>UPI Payment</strong></a><br>
        <a href="" class="text-decoration-none p1">What is UPI Payment?</a><br>
        <a href="<?php echo base_url();?>generateupi" class="text-decoration-none p1">UPI QR Code Generator</a><br>
        <a href="" class="text-decoration-none p1">UPI QR Code API</a><br>
        <a href="<?php echo base_url();?>Generatepaymentlink" class="text-decoration-none p1">UPI Payment Link Generator</a><br>
        <a href="<?php echo base_url();?>retailerupi" class="text-decoration-none p1">UPI QR Code For Retailers</a><br>
      </div>
      <div class="col-lg-3 col-md-3 col-12 mt-5">
        <form class="mt-2" action="" method="POST">
          <div class="form-group">
            <input type="email" name="email" placeholder="Enter Email Id" class="form-control form-control-sm">
          </div>
          <div class="form-group float-right">
            <button class="btn btn-info btn-sm" type="submit">Subscribe</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<script src="<?php echo base_url();?>public/assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.bundle.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<!-- <script src="<?php echo base_url();?>public/assets/js/nav.js"></script> -->
</body>
</html>