<div class="card shadow mt-5">
	<div class="card-header bg-qr"></div>
	<div class="card-body">
		<a href="<?php echo base_url();?>upi" class="text-decoration-none text-info">Home</a><br><br>
		<a href="" class="text-decoration-none text-info">What is UPI payment?</a><br><br>
		<a href="" class="text-decoration-none text-info">Bharat Interface of Money (BHIM)</a><br><br>
		<a href="" class="text-decoration-none text-info">Download & install UPI app</a><br><br>
		<a href="<?php echo base_url();?>generateupi" class="text-decoration-none text-info">UPI QR code generator</a><br><br>
		<a href="" class="text-decoration-none text-info">UPI QR code API</a><br><br>
		<a href="<?php echo base_url();?>Generatepaymentlink" class="text-decoration-none text-info">UPI Payment Link Generator</a><br><br>
		<a href="<?php echo base_url();?>retailerupi" class="text-decoration-none text-info">UPI Code For Retailer</a><br><br>
		<a href="" class="text-decoration-none text-info">UPI QR code partners program</a><br><br>
		<a href="" class="text-decoration-none text-info">UPI QR code gallery</a><br><br>
	</div>
</div>