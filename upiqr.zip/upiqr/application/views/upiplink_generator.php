<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!--Start Navbar -->
<?php include 'navbar.php';?>
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row mt-5 justify-content-center">
    <h1 class="text-info mt-5">UPI Payment Link Generator</h1>
  </div>
  <div class="row justify-content-center">
    <h2 class="text-info mt-n4">_______________________________________</h2>
  </div>
  <div class="row">
    <div class="col-lg-9 col-md-9 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">UPI Payment Link Generator</h2></div><hr>
          <p>UPI (Unified Payment Interface) application is offered to the customers of Indian banks to register with the bank and link their accounts of other banks as well. This best in class app provides comfort of an wallet , with advantage of bank account.Customer shall be able to Pay and initiated collect money requests to their contacts. Payment Address is an abstract form to represent and identify the account details, and account details remain confidential. By adding accounts of different banks, customer can manage the account in single platform.</p>
          <hr>
          <div class="row">
            <div class="col-md-6 col-12">
              <form action="" method="POST">
                
                <div class="row">
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Background Color</label>
                      <input type="text" name="bgcolor" class="form-control form-control-sm">
                    </div>
                  </div>
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Front Color</label>
                      <input type="text" name="fbcolor" class="form-control form-control-sm">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label>Payee Name<span class="text-danger">*</span></label>
                  <input type="text" name="pname" class="form-control form-control-sm" required>
                </div>
                <div class="form-group">
                  <label>UPI Id<span class="text-danger">*</span></label>
                  <input type="text" name="upi_id" class="form-control form-control-sm" required>
                </div>
                <div class="form-group">
                  <label>Bill No.<span class="text-danger">*</span></label>
                  <input type="text" name="bill" class="form-control form-control-sm" required>
                </div>
                <div class="form-group">
                  <label>Amount In(Rs.)<span class="text-danger">*</span></label>
                  <input type="number" name="amt" class="form-control form-control-sm" required>
                </div>
                <div class="form-group">
                  <button class="btn btn-info btn-sm" type="submit" name="generate_upiplink">Generate UPI Payment Link</button>
                  <button class="btn btn-warning btn-sm" type="reset">Reset</button>
                </div>
              </form>
            </div>
            <div class="col-md-6 col-12">
              <div class="card shadow mt-3">
                <div class="card-header bg-qr"></div>
                <div class="card-body" style="height:480px;">
                  <img src="" class="img-fluid">
                </div>
              </div>
            </div>
          </div>
          <hr>
          <p>For Printing Dynamic UPI QR Code on bills or integrating Dynamic UPI QR Code into your website or mobile applications to receive UPI payment against bills through any UPI App, please Contact Us. UPI API can be accessed from <a href="" class="text-decoration-none">UPI QR Code API Link</a></p>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-12 mt-5">
      <?php include 'sidebar.php';?>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<?php include 'footer.php';?>
<!-- End Footer -->