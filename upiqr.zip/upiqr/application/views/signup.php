<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!--Start Navbar -->
<?php include 'navbar.php';?>
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-6 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title text-info text-center"><h2>Signup</h2></div><hr>
          <?php if($this->session->flashdata('success') != "") { ?>
          <div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
        <?php } ?>
          <form action="<?php echo base_url().'user/Signup/register';?>" method="POST" enctype="multipart/form-data">
            <div class="row">
              <div class="col-md-12 col-12 mb-3">
                <div class="form-group">
                  <label>Full Name <span class="text-danger">*</span></label>
                  <input type="text" name="name" class="form-control form-control-sm <?php echo (form_error('name') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('name');?>">
                </div><?php echo form_error('name');?>
              </div>              
            </div>
            <div class="row">
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Mobile No.</label>
                  <input type="phone" name="mob" class="form-control form-control-sm <?php echo (form_error('mob') !="") ? 'is-invalid' : '';?>" pattern="[6-9]{1}[0-9]{9}" maxlength="10" minlength="10" value="<?php echo set_value('mob');?>">
                </div><?php echo form_error('mob');?>
              </div>
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Email <span class="text-danger">*</span></label>
                  <input type="email" name="email" class="form-control form-control-sm <?php echo (form_error('email') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('email');?>">
                </div><?php echo form_error('email');?>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Password <span class="text-danger">*</span></label>
                  <input type="password" name="password" class="form-control form-control-sm <?php echo (form_error('password') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('password');?>">
                </div><?php echo form_error('password');?>
              </div>
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Confirm Password <span class="text-danger">*</span></label>
                  <input type="text" name="cpassword" class="form-control form-control-sm <?php echo (form_error('cpassword') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('cpassword');?>">
                </div><?php echo form_error('cpassword');?>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-12 mb-3">
                <input type="file" name="image">
                <?php echo (!empty($errorImageUpload)) ? $errorImageUpload : '';?>
              </div>
              <div class="col-md-6 col-12 mb-3"></div>
            </div>
            <div class="form-group">
              <p><button class="btn btn-info btn-sm" type="submit" name="user_signup">Signup</button>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If you've already account. Please <a href="<?php echo base_url();?>user/login" class="text-decoration-none p1">Login</a> here.</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<?php include 'footer.php';?>
<!-- End Footer -->