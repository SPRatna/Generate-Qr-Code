<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!-- Navbar -->
<?php include 'navbar.php';?>
<!-- Start Carousel -->
<div id="demo" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo base_url();?>public/carousel/1.jpg" alt="1.jpg" width="100%" height="650px">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url();?>public/carousel/2.jpg" alt="2.jpg" width="100%" height="650px">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url();?>public/carousel/3.jpeg" alt="3.jpeg" width="100%" height="650px">
    </div>
  </div>
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<!-- End Carousel -->
<!-- Start Content -->
<section>
  <div class="container">
    <div class="row mt-5 mb-3">
      <div class="col-lg-3 col-md-3 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">UPI QR Code</div>
            <p>QR (Quick Response) Code used for receiving payment from UPI APPs is called UPI QR Code. UPI QR Code contains information related to payment receiver, Payers scans with UPI mobile app, the UPI QR Code of receiver to make payment. Payment is debited from payer account by the payer bank</p>
            <a href="<?php echo base_url();?>upiqrcode" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">UPI QR Code Generator</div>
            <p>Generate UPI QR Code to receive UPI payment direct into your account. Facility to generate UPI QR Code on the basis of VPA, bank account and ifsc code, mobile no and mmid. Generate, Print or download UPI QR Code and start receiving UPI payment. Get Printed UPI QR Code Stickers & Stands.</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">UPI Payment Link Generator</div>
            <p>Generate UPI payment link and share with your friends, relatives and customers to make you payment from any UPI APP. Share your payment link on whatsapp, twitter, facebook, linkedin or send payment link SMS. Generate dynamic UPI Payment link with bill no and amount to receive bill-wise</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">UPI QR Code API</div>
            <p>UPI QR Code API to integrate into your billing applications to print UPI QR Code on bills. So your customers can make you payment by scanning UPI QR Code printed on the bills. UPI QR Code API is available for receiving payment against sale bills, service bills, fees, taxes, extra.</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-3 mb-3">
      
      <!-- <div class="col-lg-4 col-md-4 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">Bharat QR Code</div>
            <p>Bharat QR Code developed by NPCI jointly worked with International card Schemes to develop a common standard QR code specifications. BQR is Person to Merchant (P2M) Mobile payment solution. Payment Using BQR enabled Mobile banking Application/wallet</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">Dynamic Bharat QR Code</div>
            <p>Bharat QR Code is used for receveing merchants payments. In case you are unable to receive UPI Payments or need payment response on your website, you should use Bharat QR Code API. With Dynamic Bharat QR Code, you can generate dynamic Bharat QR Code</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div> -->
    </div>
    <!-- <div class="row mt-3 mb-3">
      <div class="col-lg-4 col-md-4 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">QR Code API</div>
            <p>Need to generate bulk QR Code, you can use our QR Code API. It is very simple to integrate our QR Code API into your Application.</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">QR Code Generator</div>
            <p>A QR code consists of black squares arranged in a square grid on a white background, which can be read by an imaging device such as a camera.</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12 mb-3">
        <div class="card shadow">
          <div class="card-header bg-qr"></div>
          <div class="card-body">
            <div class="card-title text-info">QR Code Scanner</div>
            <p>Want to read QR Code, you can do with our QR Code Scanner. You can also download our Bar Code Scanner to read all types of Bar Codes and QR Codes.</p>
            <a href="" class="btn btn-info btn-sm">Read More <i class='fas fa-angle-double-right'></i></a>
          </div>
        </div>
      </div>
    </div> -->
  </div>
</section>
<?php include 'footer.php';?>