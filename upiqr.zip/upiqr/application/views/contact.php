<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!--Start Navbar -->
<?php include 'navbar.php';?>
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-lg-9 col-md-9 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">Contact Us</h2></div><hr>
          <form action="" method="POST">
            <div class="row">
              <div class="col-md-6 col-12 mt-3 mb-3">
                <div class="form-group">
                  <label>Full Name <span class="text-danger">*</span></label>
                  <input type="text" name="user" class="form-control form-control-sm" required>
                </div>
              </div>
              <div class="col-md-6 col-12 mt-3 mb-3">
                <label>Email <span class="text-danger">*</span></label>
                <input type="email" name="umail" class="form-control form-control-sm" required>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 col-12">
              <div class="form-group">
                <label>Message <span class="text-danger">*</span></label>
                <textarea class="form-control form-control-sm" rows="4" name="msg" placeholder="Say something..." required></textarea>
              </div>
            </div>
            </div>
            <div class="form-group">
              <button class="btn btn-info btn-sm" type="submit">Send Message</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title text-info"><h2>Office Address:</h2></div><hr>
          <address>
            XYZ Technologies Pvt. Ltd.<br> 
            District Center<br>
            West Janakpuri<br>
            New Delhi<br>
            India<br>
            <hr>
            Email: admin@xyztech.com<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: customercare@xyztech.com<br>
            <hr>
            Phone : 011-123456<br>
            Mobile: 8789532436
          </address>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<?php include 'footer.php';?>
<!-- End Footer -->