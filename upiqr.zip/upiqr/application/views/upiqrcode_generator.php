<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!--Start Navbar -->
<?php include 'navbar.php';?>
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row mt-5 justify-content-center">
    <h1 class="text-info mt-5">UPI QR Code Generator</h1>
  </div>
  <div class="row justify-content-center">
    <h2 class="text-info mt-n4">________________________________</h2>
  </div>
  <div class="row">
    <div class="col-lg-9 col-md-9 col-12 mt-3">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">UPI QR Code Generator</h2></div><hr>
          <p>UPI (Unified Payment Interface) application is offered to the customers of Indian banks to register with the bank and link their accounts of other banks as well. This best in class app provides comfort of an wallet , with advantage of bank account.Customer shall be able to Pay and initiated collect money requests to their contacts. Payment Address is an abstract form to represent and identify the account details, and account details remain confidential. By adding accounts of different banks, customer can manage the account in single platform.</p>
          <hr>
          <div class="row">
            <div class="col-md-6 col-12">
                <?php if($this->session->flashdata('success') != "") { ?>
                  <div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
                <?php } ?>
              <form action="<?php echo base_url().'generateupi/add_data';?>" method="POST">
                <div class="form-group">
                  <label>Select Payment Address Type<span class="text-danger">*</span></label>
                  <select class="form-control form-control-sm <?php echo (form_error('pmode') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('pmode');?>" name="pmode">
                    <option selected disabled>Select Payment Mode</option>
                    <option value="ba">Bank Account</option>
                    <option value="vpa">Virtual Private Address</option>
                    <option value="mp">Mobile Payment</option>
                  </select>
                  <?php echo form_error('pmode');?>
                </div>
                <div class="row">
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Background Color</label>
                      <input type="text" name="bgc" class="form-control form-control-sm <?php echo (form_error('bgc') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('bgc');?>">
                    </div><?php echo form_error('bgc');?>
                  </div>
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Front Color</label>
                      <input type="text" name="ftc" class="form-control form-control-sm <?php echo (form_error('ftc') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('ftc');?>">
                    </div><?php echo form_error('ftc');?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Payee Name<span class="text-danger">*</span></label>
                  <input type="text" name="payee" class="form-control form-control-sm <?php echo (form_error('payee') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('payee');?>">
                </div><?php echo form_error('payee');?>
                <div class="form-group">
                  <label>Payee Address<span class="text-danger">*</span></label>
                  <textarea class="form-control form-control-sm <?php echo (form_error('paddr') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('paddr');?>" rows="3" name="paddr">
                  
                  </textarea><?php echo form_error('paddr');?>
                </div>
                <div class="row">
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Bank Name <span class="text-danger">*</span></label>
                      <input type="text" name="bank" class="form-control form-control-sm <?php echo (form_error('bank') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('bank');?>">
                    </div><?php echo form_error('bank');?>
                  </div>
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>IFSC Code<span class="text-danger">*</span></label>
                      <input type="text" name="ifsc" class="form-control form-control-sm <?php echo (form_error('ifsc') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('ifsc');?>">
                    </div><?php echo form_error('ifsc');?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Mobile<span class="text-danger">*</span></label>
                      <input type="phone" name="mob" class="form-control form-control-sm <?php echo (form_error('mob') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('mob');?>" minlength="10" maxlength="10">
                    </div><?php echo form_error('mob');?>
                  </div>
                  <div class="col-md-6 col-12">
                    <div class="form-group">
                      <label>Email <span class="text-danger">*</span></label>
                      <input type="email" name="email" class="form-control form-control-sm <?php echo (form_error('email') !="") ? 'is-invalid' : '';?>"  value="<?php echo set_value('email');?>">
                    </div><?php echo form_error('email');?>
                  </div>
                </div>
                <div class="form-group">
                  <button class="btn btn-info btn-sm" type="submit" name="generateupi">Generate UPI QR Code</button>
                  <button class="btn btn-warning btn-sm" type="reset">Reset</button>
                </div>
              </form>
            </div>
            <div class="col-md-6 col-12">
              <div class="card shadow mt-3">
                <div class="card-header bg-qr"></div>
                <div class="card-body" style="height:450px;">
                  <img src="<?php echo base_url().'public/qrcodeci/';?>" class="img-fluid">
                </div>
              </div>
            </div>
          </div>
          <hr>
          <p>For Printing Dynamic UPI QR Code on bills or integrating Dynamic UPI QR Code into your website or mobile applications to receive UPI payment against bills through any UPI App, please Contact Us. UPI API can be accessed from <a href="" class="text-decoration-none">UPI QR Code API Link</a></p>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-12 mt-3">
      <?php include 'sidebar.php';?>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<?php include 'footer.php';?>
<!-- End Footer -->