<?php include 'header.php';?>
<title>Partner | Dashboard</title>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php include 'navbar.php';?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->
  <?php include 'sidebar.php';?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">UPI QR Code Generator</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo base_url();?>partners/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo base_url();?>partners/generateupiqr">UPI QR Code Generator</a></li>
              </ol>
              </div><!-- /.col -->
              </div><!-- /.row -->
              </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-12">
                    <div class="card card-info card-outline">
                      <div class="card-body">
                        <div class="row">
                          <div class="col-md-6 col-12">
                            <form action="" method="POST">
                              <div class="form-group">
                                <label>Select Payment Address Type<span class="text-danger">*</span></label>
                                <select class="form-control form-control-sm" name="payAddress">
                                  <option selected disabled>Select Payment Mode</option>
                                  <option value="ba">Bank Account</option>
                                  <option value="vpa">Virtual Private Address</option>
                                  <option value="mp">Mobile Payment</option>
                                </select>
                              </div>
                              <div class="row">
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>Background Color</label>
                                    <input type="text" name="bgcolor" class="form-control form-control-sm">
                                  </div>
                                </div>
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>Front Color</label>
                                    <input type="text" name="fbcolor" class="form-control form-control-sm">
                                  </div>
                                </div>
                              </div>
                              <div class="form-group">
                                <label>Payee Name<span class="text-danger">*</span></label>
                                <input type="text" name="pname" class="form-control form-control-sm" required>
                              </div>
                              <div class="form-group">
                                <label>Payee Address<span class="text-danger">*</span></label>
                                <textarea class="form-control form-control-sm" rows="3" name="paddress">
                                
                                </textarea>
                              </div>
                              <div class="row">
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>Bank Name <span class="text-danger">*</span></label>
                                    <input type="text" name="bank" class="form-control form-control-sm" required>
                                  </div>
                                </div>
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>IFSC Code<span class="text-danger">*</span></label>
                                    <input type="text" name="ifsc" class="form-control form-control-sm" required>
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>Mobile<span class="text-danger">*</span></label>
                                    <input type="phone" name="mob" class="form-control form-control-sm" minlength="10" maxlength="10" required>
                                  </div>
                                </div>
                                <div class="col-md-6 col-12">
                                  <div class="form-group">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control form-control-sm" required>
                                  </div>
                                </div>
                              </div>
                              <div class="form-group">
                                <button class="btn btn-info btn-sm" type="submit" name="generateupi">Generate UPI QR Code</button>
                                <button class="btn btn-warning btn-sm" type="reset">Reset</button>
                              </div>
                            </form>
                          </div>
                          <div class="col-md-6 col-12">
                            <div class="card shadow mt-3">
                              <div class="card-header bg-info"></div>
                              <div class="card-body" style="height:450px;">
                                <img src="" class="img-fluid">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div><!-- /.card -->
                    </div>
                    <!-- /.col-md-6 -->
                  </div>
                  <!-- /.row -->
                  </div><!-- /.container-fluid -->
                </div>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->
              <!-- Main Footer -->
              <footer class="main-footer">
                <!-- To the right -->
                <div class="float-right d-none d-sm-inline">
                  <a href="">Privacy Policy</a> | <a href="">Terms & Conditions</a>
                </div>
                <!-- Default to the left -->
                <strong>Copyright &copy; 2021 <a href="https://ramsunnetwork.com">Ramsun Enterprise Payment Network</a>.</strong> All rights reserved.
              </footer>
            </div>
            <!-- ./wrapper -->
            <!-- REQUIRED SCRIPTS -->
            <!-- jQuery -->
            <script src="<?php echo base_url();?>public/admin/plugins/jquery/jquery.min.js"></script>
            <!-- Bootstrap 4 -->
            <script src="<?php echo base_url();?>public/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
            <!-- AdminLTE App -->
            <script src="<?php echo base_url();?>public/admin/dist/js/adminlte.min.js"></script>
            <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
          </body>
        </html>