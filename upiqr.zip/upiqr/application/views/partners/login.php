<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="description" content="UPI QR Code">
  <meta name="keywords" content="UPI QR Code">
  <meta name="author" content="Suraj Prakash Ratna">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>public/assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/assets/css/nav.css">
<title>Partner | Login</title>
</head>
<body class="bg-light">
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row justify-content-center mt-5">
    <div class="col-lg-4 col-md-4 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title text-info text-center"><h2>Partner's Login</h2></div><hr>
          <?php 
           if(!empty($this->session->flashdata('msg')))
           {
            echo "<div class='alert alert-danger'>".$this->session->flashdata('msg')."</div>";
           }
          ?>
          <?php echo form_open('partners/Login/authenticate');?>
            <div class="form-group">
              <?php 
              echo form_label('Username | Email', 'username');
              echo form_input(['class'=>'form-control form-control-sm', 'type'=>'email', 'name'=>'username', 'value'=>set_value('username')]);
              ?>
            </div><?php echo form_error('username') ;?>
            <div class="form-group">
              <?php 
              echo form_label('Password', 'password');
              echo form_password(['class'=>'form-control form-control-sm', 'type'=>'password', 'name'=>'password', 'value'=>set_value('password')]);
              ?>
            </div><?php echo form_error('password') ;?>
            <div class="form-group">
              <p>If you've not account. Please <a href="<?php echo base_url();?>partners/signup" class="text-decoration-none p1">Signup</a> here.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <button class="btn btn-info btn-sm" type="submit" name="partner_login">Login</button></p>
            </div>
          <?php echo form_close();?>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<script src="<?php echo base_url();?>public/assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.bundle.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="<?php echo base_url();?>public/assets/js/nav.js"></script>
</body>
</html>
<!-- End Footer -->