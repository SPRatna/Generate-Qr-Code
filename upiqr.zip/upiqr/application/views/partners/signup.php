<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="description" content="UPI QR Code">
  <meta name="keywords" content="UPI QR Code">
  <meta name="author" content="Suraj Prakash Ratna">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>public/assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/assets/css/nav.css">
<title>Partner | Signup</title>
</head>
<body class="bg-light">
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-6 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title text-info text-center"><h2>Partner's Signup</h2></div><hr>
          <form action="" method="POST">
            <div class="row">
              <div class="col-md-12 col-12 mb-3">
                <div class="form-group">
                  <label>Full Name <span class="text-danger">*</span></label>
                  <input type="text" name="name" class="form-control form-control-sm" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Mobile No.</label>
                  <input type="phone" name="mob" class="form-control form-control-sm" minlength="10" maxlength="10">
                </div>
              </div>
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Email <span class="text-danger">*</span></label>
                  <input type="email" name="email" class="form-control form-control-sm" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Password <span class="text-danger">*</span></label>
                  <input type="password" name="password" class="form-control form-control-sm" required>
                </div>
              </div>
              <div class="col-md-6 col-12 mb-3">
                <div class="form-group">
                  <label>Confirm Password <span class="text-danger">*</span></label>
                  <input type="text" name="cpassword" class="form-control form-control-sm" required>
                </div>
              </div>
            </div>
            
            <div class="form-group">
              <p><button class="btn btn-info btn-sm" type="submit" name="partner_signup">Signup</button>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If you've already account. Please <a href="<?php echo base_url();?>partners/login" class="text-decoration-none p1">Login</a> here.</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<script src="<?php echo base_url();?>public/assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.js"></script>
<script src="<?php echo base_url();?>public/assets/js/bootstrap.bundle.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="<?php echo base_url();?>public/assets/js/nav.js"></script>
</body>
</html>
<!-- End Footer -->