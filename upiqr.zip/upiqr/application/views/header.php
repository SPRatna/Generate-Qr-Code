<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="description" content="UPI QR Code">
  <meta name="keywords" content="UPI QR Code">
  <meta name="author" content="Suraj Prakash Ratna">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>public/assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/assets/css/nav.css">
<title>Home</title>
</head>
<body>