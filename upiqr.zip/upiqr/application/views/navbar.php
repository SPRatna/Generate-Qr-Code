<nav class="navbar navbar-expand-md navbar-light fixed-top" style="background-color:#e3f2fd;">
  <!-- Brand -->
  <a class="navbar-brand" href="#">UPI QR Code Logo</a>
  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
  <span class="navbar-toggler-icon"></span>
  </button>
  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url();?>welcome">Home</a>
      </li>&nbsp;&nbsp;&nbsp;
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="upiqrcode" data-toggle="dropdown">
          UPI QR Code
        </a>
        <div class="dropdown-menu">
          <div class="dropdown-header"><a href="<?php echo base_url();?>upiqrcode" class="text-decoration-none"><strong>UPI QR Code</strong></a></div>
          <!-- <a class="dropdown-item" href="#">UPI QR Code</a> -->
          <a class="dropdown-item" href="<?php echo base_url();?>generateupi">UPI QR Code Generator</a>
          <a class="dropdown-item" href="<?php echo base_url();?>Generatepaymentlink">UPI Payment Link Generator</a>
          <a class="dropdown-item" href="<?php echo base_url();?>retailerupi">UPI QR Code For Retailers</a>
        </div>
      </li>&nbsp;&nbsp;&nbsp;
      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="bharatqrcode" data-toggle="dropdown">
          Bharat QR Code
        </a>
        <div class="dropdown-menu">
          <div class="dropdown-header"><a href="" class="text-decoration-none"><strong>Bharat QR Code</strong></a></div>
          <a class="dropdown-item text-capitalize" href="#">Bharat QR Code Generator</a>
          <a class="dropdown-item text-capitalize" href="#">Dynamic Bharat QR Code Generator</a>
          <a class="dropdown-item text-capitalize" href="#">Apply for Bharat QR Code</a>
        </div>
      </li>&nbsp;&nbsp;&nbsp; -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="developer" data-toggle="dropdown">
          Developer
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">UPI QR Code API</a>
          <a class="dropdown-item" href="#">UPI Payment Link API</a>
        </div>
      </li>&nbsp;&nbsp;&nbsp;
      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="partners" data-toggle="dropdown">
          Partners
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item text-capitalize" href="<?php echo base_url();?>partners/login">Login</a>
          <a class="dropdown-item text-capitalize" href="<?php echo base_url();?>partners/signup">Signup</a>
          <a class="dropdown-item text-capitalize" href="#">Partnership Opportunity</a>
        </div>
      </li>&nbsp;&nbsp;&nbsp; -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url();?>contact">Contact</a>
      </li>&nbsp;&nbsp;&nbsp;
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url();?>user/login">Login</a>
      </li>&nbsp;&nbsp;&nbsp;
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url();?>user/signup">Signup</a>
      </li>
    </ul>
  </div>
</nav>