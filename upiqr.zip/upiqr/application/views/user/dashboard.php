<?php include 'header.php';?>
<title>User | Dashboard</title>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <?php include 'navbar.php';?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include 'sidebar.php';?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active"><a href="<?php echo base_url();?>user/dashboard">Home</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-3 col-md-3 col-12">
            <div class="card card-info card-outline">
              <div class="card-body bg-primary">
                <h5 class="card-title">Visitors From Your Link</h5><br>
                <hr>
                <a href="#" class="card-link">View Details &nbsp;<i class='far fa-arrow-alt-circle-right float-right mt-2'></i></a>
              </div>
            </div><!-- /.card -->
          </div>
          <div class="col-lg-3 col-md-3 col-12">
            <div class="card card-info card-outline">
              <div class="card-body bg-warning">
                <h5 class="card-title">Total Incentives</h5><br>
                <hr>
                <a href="#" class="card-link">View Details &nbsp;<i class='far fa-arrow-alt-circle-right float-right mt-2'></i></a>
              </div>
            </div><!-- /.card -->
          </div>
          <div class="col-lg-3 col-md-3 col-12">
            <div class="card card-info card-outline">
              <div class="card-body bg-success">
                <h5 class="card-title">Incentives Transferred</h5><br>
                <hr>
                <a href="#" class="card-link">View Details &nbsp;<i class='far fa-arrow-alt-circle-right float-right mt-2'></i></a>
              </div>
            </div><!-- /.card -->
          </div>
          <div class="col-lg-3 col-md-3 col-12">
            <div class="card card-info card-outline">
              <div class="card-body bg-danger">
                <h5 class="card-title">Incentives Balance</h5><br>
                <hr>
                <a href="#" class="card-link">View Details &nbsp;<i class='far fa-arrow-alt-circle-right float-right mt-2'></i></a>
              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <div class="row justify-content-center">
          <div class="col-lg-12 col-md-12 col-12 mb-3">
            <form action="" method="POST">
              <div class="form-inline">
                <div class="form-group">
                  <input type="date" name="s_date" class="form-control form-control-sm">
                </div>&nbsp;&nbsp;&nbsp;&nbsp;
                <div class="form-group">
                  <input type="date" name="s_date" class="form-control form-control-sm">
                </div>&nbsp;&nbsp;&nbsp;&nbsp;
                <div class="form-group">
                  <button class="btn btn-info btn-sm" type="submit">Filter</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-12">
            <div class="card card-info card-outline">
              <div class="card-body">

              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      <a href="">Privacy Policy</a> | <a href="">Terms & Conditions</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2021 <a href="https://ramsunnetwork.com">Ramsun Enterprise Payment Network</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo base_url();?>public/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>public/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>public/admin/dist/js/adminlte.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
