<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include 'header.php';?>
<!--Start Navbar -->
<?php include 'navbar.php';?>
<!-- End Navbar -->
<!-- Start Content -->
<div class="container-fluid">
  <div class="row mt-5 justify-content-center">
    <h1 class="text-info mt-5">UPI QR Code</h1>
  </div>
  <div class="row justify-content-center">
    <h2 class="text-info mt-n4">__________________</h2>
  </div>
  <div class="row">
    <div class="col-lg-9 col-md-9 col-12 mt-5">
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">UPI QR Code</h2></div><hr>
          <p>QR Code used for receiving payment from UPI APPs is called UPI QR Code. UPI QR Code contains information related to payment receiver, Payers scans with UPI mobile app, the UPI QR Code of receiver to make payment. Payment is debited from payer account by the payer bank and payer bank sends credit details to receiver bank and reciver bank credit the amount into the payers bank account. After amount is credited into payers account, payer can use the amount to make payment or can withdraw the amount.</p>
        </div>
      </div>
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">UPI QR Code Features</h2></div><hr>
          <ul>
            <li>Instant credit to your bank account.</li>
            <li>No transactions charges</li>
            <li>No monthly charges</li>
            <li>No annual charges</li>
            <li>No maintenance charges</li>
            <li>No swipe(EDC) machine required</li>
            <li>No smart phone required to receive UPI payments</li>
            <li>No installation required</li>
            <li>No need to share your mobile number</li>
            <li>No need to send payment request</li>
          </ul>
        </div>
      </div>
      <div class="card shadow mt-5">
        <div class="card-header bg-qr"></div>
        <div class="card-body">
          <div class="card-title"><h2 class="text-info">How to receive UPI payments</h2></div><hr>
          <ul>
            <li>By installing any UPI App and creating VPA/ UPI Id</li>
            <li>By bank account number & IFSC code</li>
            <li>By mobile number and MMID</li>
            <li>By aadhar number</li>
            <li>By RuPay card number</li>
            <li>By a one time or time/amount limited tokens issued by a PSP</li>
            <li>By PPI card number</li>
            <li>By user id issued by a PSP</li>
            <li>By account identifier issued by PSP</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-12 mt-5">
      <?php include 'sidebar.php';?>
    </div>
  </div>
</div>
<!-- End Content -->
<!-- Start Footer -->
<?php include 'footer.php';?>
<!-- End Footer -->