<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class partnerModel extends CI_Model {

	public function getByUsername($username)
	{
		$this->db->where('username', $username);
		$partner = $this->db->get('partner')->row_array();
	    return $partner;
	}

}
?>