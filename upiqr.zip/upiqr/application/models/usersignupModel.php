<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class usersignupModel extends CI_Model 
{

	public function create($formArray)
	{
		$this->db->insert('user', $formArray);
	}	

}
?>