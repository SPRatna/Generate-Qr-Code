<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class userloginModel extends CI_Model {

	public function isvalidate($username, $password)
	{
		
	}

}
?>