<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class userModel extends CI_Model {

	public function getByUsername($username)
	{
		$this->db->where('username', $username);
		$user = $this->db->get('user')->row_array();
	    return $user;
	}

	public function create($dataArray)
	{
		$this->db->insert('qr', $dataArray);
	}
	
    public function insert_data($qr)
    {
        $this->db->insert($this->qrcode, $qr);
        return ($this->db->affected_rows());
    }

}
?>