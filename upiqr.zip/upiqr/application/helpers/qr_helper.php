<?php 
 
 function qrImage($dir,$bgc, $ftc)
 {
 	$CI =& get_instance();

 	$config['cacheable']    = true;
        $config['imagedir']     = $dir;
        $config['quality']      = true;
        $config['size']         = '1024';
        $config['black']        = $ftc;
        $config['white']        = $bgc;
        $this->ciqrcode->initialize($config);
 }

?>